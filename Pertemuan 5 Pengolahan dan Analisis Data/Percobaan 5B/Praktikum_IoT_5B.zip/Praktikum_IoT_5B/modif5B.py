import json
import time
import paho.mqtt.client as mqtt
import pandas as pd
import matplotlib.pyplot as plt

# ==================================================
# KONFIGURASI MQTT
# ==================================================
BROKER = "broker.hivemq.com"
PORT = 1883

# Harus sama dengan topic pada program ESP8266
TOPIC = "unsoed/tkomputer/iot/modul5/suhu"

# Jumlah data yang dikumpulkan
JUMLAH_SAMPEL = 30

# Tempat menyimpan data MQTT
data = []


# ==================================================
# FUNGSI KETIKA BERHASIL TERHUBUNG KE MQTT
# ==================================================
def on_connect(client, userdata, flags, reason_code, properties):
    print("Terhubung ke broker, kode:", reason_code)

    # Subscribe agar Python menerima data suhu dari ESP8266
    client.subscribe(TOPIC)

    print("Subscribe ke topic:", TOPIC)


# ==================================================
# FUNGSI KETIKA PESAN MQTT DITERIMA
# ==================================================
def on_message(client, userdata, msg):
    try:
        # Mengubah pesan JSON menjadi objek Python
        payload = json.loads(msg.payload.decode())

        # Mengambil nilai suhu dari JSON
        suhu = float(payload["suhu"])

    except (ValueError, KeyError, TypeError, json.JSONDecodeError):
        print("Data tidak valid, diabaikan")
        return

    # Menyimpan waktu penerimaan dan nilai suhu
    data.append({
        "waktu": time.strftime("%Y-%m-%d %H:%M:%S"),
        "suhu": suhu
    })

    # Menampilkan jumlah sampel yang telah diterima
    print(f"[{len(data)}/{JUMLAH_SAMPEL}] Suhu = {suhu:.2f} C")

    # Menghentikan pengumpulan setelah 30 sampel
    if len(data) >= JUMLAH_SAMPEL:
        client.disconnect()


# ==================================================
# TAHAP 1: AKUISISI DATA DARI MQTT
# ==================================================
client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)
client.on_connect = on_connect
client.on_message = on_message

print("Menghubungkan ke broker MQTT...")

client.connect(BROKER, PORT, 60)

# Menjalankan proses penerimaan pesan MQTT
client.loop_forever()


# ==================================================
# TAHAP 2: MENYIMPAN DATA KE CSV
# ==================================================
df = pd.DataFrame(data)

# Menyimpan data awal sebelum analisis
df.to_csv("data_suhu.csv", index=False)

print("\nData tersimpan di data_suhu.csv")


# ==================================================
# TAHAP 3: ANALISIS DATA DAN DETEKSI ANOMALI
# ==================================================
if not df.empty:

    # ----------------------------------------------
    # A. ANALISIS SUHU ASLI TANPA MOVING AVERAGE
    # ----------------------------------------------

    # Menghitung rata-rata suhu asli
    rata2 = df["suhu"].mean()

    # Menghitung simpangan baku suhu asli
    std = df["suhu"].std()

    # Menghitung z-score data asli
    if pd.isna(std) or std == 0:
        df["zscore"] = 0.0
    else:
        df["zscore"] = (df["suhu"] - rata2) / std

    # Menandai anomali jika nilai absolut z-score > 2
    df["anomali"] = df["zscore"].abs() > 2

    # Menghitung jumlah anomali sebelum moving average
    jumlah_anomali_awal = int(df["anomali"].sum())


    # ----------------------------------------------
    # B. MODIFIKASI: MOVING AVERAGE JENDELA 5 DATA
    # ----------------------------------------------

    # Menghitung rata-rata bergerak dari maksimal 5 data
    # min_periods=1 memungkinkan perhitungan sejak data pertama
    df["suhu_ma5"] = df["suhu"].rolling(
        window=5,
        min_periods=1
    ).mean()


    # ----------------------------------------------
    # C. Z-SCORE SETELAH MOVING AVERAGE
    # ----------------------------------------------

    # Menghitung rata-rata suhu hasil moving average
    rata2_ma5 = df["suhu_ma5"].mean()

    # Menghitung simpangan baku hasil moving average
    std_ma5 = df["suhu_ma5"].std()

    # Menghitung z-score data hasil moving average
    if pd.isna(std_ma5) or std_ma5 == 0:
        df["zscore_ma5"] = 0.0
    else:
        df["zscore_ma5"] = (
            df["suhu_ma5"] - rata2_ma5
        ) / std_ma5

    # Menandai anomali setelah moving average
    df["anomali_ma5"] = df["zscore_ma5"].abs() > 2

    # Menghitung jumlah anomali setelah moving average
    jumlah_anomali_ma5 = int(df["anomali_ma5"].sum())


    # ----------------------------------------------
    # D. MENAMPILKAN HASIL ANALISIS
    # ----------------------------------------------
    print("\n========== HASIL ANALISIS ==========")

    print(f"Jumlah data                  : {len(df)}")

    print(f"Rata-rata suhu asli          : {rata2:.2f} C")
    print(f"Simpangan baku suhu asli     : {std:.2f}")
    print(f"Suhu minimum                 : {df['suhu'].min():.2f} C")
    print(f"Suhu maksimum                : {df['suhu'].max():.2f} C")

    print("\n--- PERBANDINGAN DETEKSI ANOMALI ---")

    print(
        f"Anomali sebelum moving average: "
        f"{jumlah_anomali_awal}"
    )

    print(
        f"Anomali setelah moving average: "
        f"{jumlah_anomali_ma5}"
    )

    # Menghitung selisih jumlah anomali
    selisih = jumlah_anomali_awal - jumlah_anomali_ma5

    print(f"Selisih jumlah anomali        : {selisih}")

    if selisih > 0:
        print("Jumlah anomali berkurang setelah moving average.")
    elif selisih < 0:
        print("Jumlah anomali bertambah setelah moving average.")
    else:
        print("Jumlah anomali tetap sama.")


    # ----------------------------------------------
    # E. MENYIMPAN SEMUA HASIL ANALISIS KE CSV
    # ----------------------------------------------

    # CSV berisi data asli, hasil filter, kedua z-score,
    # dan status anomali sebelum maupun sesudah filter
    df.to_csv("data_suhu.csv", index=False)

    print("\nHasil lengkap disimpan di data_suhu.csv")


    # ==================================================
    # TAHAP 4: VISUALISASI DATA
    # ==================================================

    plt.figure(figsize=(10, 5))

    # Garis suhu asli
    plt.plot(
        df.index,
        df["suhu"],
        marker="o",
        label="Suhu asli"
    )

    # Garis hasil moving average
    plt.plot(
        df.index,
        df["suhu_ma5"],
        marker=".",
        label="Moving average (5 data)"
    )

    # Mengambil data yang menjadi anomali setelah filter
    anom_ma5 = df[df["anomali_ma5"]]

    # Menandai anomali hasil moving average dengan titik merah
    plt.scatter(
        anom_ma5.index,
        anom_ma5["suhu_ma5"],
        color="red",
        s=100,
        label="Anomali setelah MA",
        zorder=3
    )

    # Garis rata-rata suhu asli
    plt.axhline(
        rata2,
        color="gray",
        linestyle="--",
        label="Rata-rata suhu asli"
    )

    # Memberi label dan judul grafik
    plt.xlabel("Urutan data")
    plt.ylabel("Suhu (°C)")
    plt.title("Suhu Asli dan Moving Average")

    # Menampilkan legenda dan merapikan tata letak
    plt.legend()
    plt.tight_layout()

    # Menyimpan grafik ke file PNG
    plt.savefig("grafik_suhu.png")

    print("Grafik tersimpan di grafik_suhu.png")

    # Menampilkan grafik
    plt.show()

else:
    print("Tidak ada data yang diterima.")
    