import json
import time
import paho.mqtt.client as mqtt
import pandas as pd
import matplotlib.pyplot as plt

# Konfigurasi broker dan topic
BROKER = "broker.hivemq.com"
PORT = 1883
TOPIC = "unsoed/tkomputer/iot/modul5/suhu"
JUMLAH_SAMPEL = 30

data = []

# Dipanggil ketika Python terhubung ke broker
def on_connect(client, userdata, flags, reason_code, properties):
    print("Terhubung ke broker, kode:", reason_code)
    client.subscribe(TOPIC)
    print("Subscribe ke topic:", TOPIC)

# Dipanggil ketika ada pesan MQTT masuk
def on_message(client, userdata, msg):
    try:
        payload = json.loads(msg.payload.decode())
        suhu = float(payload["suhu"])
    except (ValueError, KeyError, TypeError):
        print("Data tidak valid, diabaikan")
        return
    except json.JSONDecodeError:
        print("Format JSON tidak valid, diabaikan")
        return

    data.append({
        "waktu": time.strftime("%Y-%m-%d %H:%M:%S"),
        "suhu": suhu
    })

    print(f"[{len(data)}/{JUMLAH_SAMPEL}] Suhu = {suhu:.2f} C")

    if len(data) >= JUMLAH_SAMPEL:
        client.disconnect()

# Tahap 1: akuisisi data dari MQTT
client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)
client.on_connect = on_connect
client.on_message = on_message

print("Menghubungkan ke broker MQTT...")
client.connect(BROKER, PORT, 60)
client.loop_forever()

# Tahap 2: simpan data ke CSV
df = pd.DataFrame(data)
df.to_csv("data_suhu.csv", index=False)
print("\nData tersimpan di data_suhu.csv")

if not df.empty:
    # Tahap 3: analisis statistik dan deteksi anomali
    rata2 = df["suhu"].mean()
    std = df["suhu"].std()

    if pd.isna(std) or std == 0:
        df["zscore"] = 0.0
    else:
        df["zscore"] = (df["suhu"] - rata2) / std

    df["anomali"] = df["zscore"].abs() > 2

    # Simpan hasil analisis ke CSV
    df.to_csv("data_suhu.csv", index=False)

    print("\n===== HASIL ANALISIS =====")
    print(f"Jumlah data   : {len(df)}")
    print(f"Rata-rata     : {rata2:.2f} C")
    print(f"Std deviasi   : {std:.2f}")
    print(f"Minimum       : {df['suhu'].min():.2f} C")
    print(f"Maksimum      : {df['suhu'].max():.2f} C")
    print(f"Jumlah anomali: {int(df['anomali'].sum())}")

    # Tahap 4: visualisasi
    plt.figure(figsize=(10, 4))
    plt.plot(df.index, df["suhu"], marker="o", label="Suhu")

    anom = df[df["anomali"]]
    plt.scatter(
        anom.index, anom["suhu"],
        color="red", s=100, label="Anomali", zorder=3
    )

    plt.axhline(
        rata2, color="gray", linestyle="--", label="Rata-rata"
    )
    plt.xlabel("Urutan data")
    plt.ylabel("Suhu (°C)")
    plt.title("Data Suhu dan Deteksi Anomali")
    plt.legend()
    plt.tight_layout()
    plt.savefig("grafik_suhu.png")

    print("Grafik tersimpan di grafik_suhu.png")
    plt.show()
else:
    print("Tidak ada data yang diterima.")